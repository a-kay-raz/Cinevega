# Merge status

## What is preserved from the APK

The `cinemovie-ui/` directory is the compiled frontend/resource payload extracted from `Cinemovie_1.apk` and includes the deployed HTML, JavaScript, CSS and image/assets.

## What comes from Vega

The GitHub workflow pulls official `vega-org/vega-app` v4.0.6 at build time. This avoids pretending the APK contains the native Vega source and ensures the native capabilities come from the actual open-source repository.

## Capability targets covered by the integration layer

Provider management, provider settings, stream resolution/aggregation, quality selection, subtitles, audio tracks, player abstraction, continue watching, downloads, watchlist, external player/downloader, custom sources and native networking/storage are the intended combined capability surface.

## Important limitation

Because the CineMovie APK contains a production/compiled frontend rather than the original TypeScript/TSX project, the exact one-to-one React component merge cannot be reconstructed from the APK alone. The package therefore keeps the extracted UI assets intact and layers a typed capability bridge while the official Vega source is fetched during the GitHub build.
