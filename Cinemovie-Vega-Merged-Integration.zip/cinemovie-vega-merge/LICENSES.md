# Third-party licensing

Vega App is a public repository under the Apache-2.0 license. See:
https://github.com/vega-org/vega-app/blob/main/LICENSE

This package does not replace the upstream license. When distributing a build containing Vega source, retain the upstream license and notices required by Apache-2.0.
