# Cinemovie UI extracted from APK

This package contains the deployed web frontend embedded inside Cinemovie_1.apk.

## Architecture detected
- Android wrapper: Capacitor
- Frontend bundle: React/Vite-style production build
- Main HTML: index.html
- Main CSS: assets/index-52tEpaFR.css
- Main JS bundle: assets/index-CiQBCZxX.js
- React vendor bundle: assets/vendor-react-l0sNRNKZ.js
- Motion/animation vendor: assets/vendor-motion-BxVvxank.js
- Query/data vendor: assets/vendor-query-OUphFNw8.js
- Supabase vendor: assets/vendor-supabase-dHqWAoqd.js
- HLS vendor: assets/vendor-hls-DPIT2aZJ.js

## Important
These are the compiled/deployed frontend files extracted from the APK.
The original developer's uncompiled TS/TSX source files, project configuration, and commit history are not necessarily recoverable from an APK.

The APK's version.json also contains a GitHub reference:
https://github.com/Extroos/MovieTester123

No source maps were found in the extracted frontend bundle.
