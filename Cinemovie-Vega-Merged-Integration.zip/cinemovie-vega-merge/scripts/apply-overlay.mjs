import {cp, mkdir, readFile, writeFile} from 'node:fs/promises';
import {dirname, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const packageRoot = resolve(root, '..');
const vegaRoot = resolve(process.argv[2] ?? resolve(packageRoot, 'vendor/vega-app'));

await mkdir(resolve(vegaRoot, 'src/cinemovie-vega'), {recursive: true});
await cp(resolve(packageRoot, 'src/cinemovie-vega'), resolve(vegaRoot, 'src/cinemovie-vega'), {recursive: true});
await mkdir(resolve(vegaRoot, 'assets/cinemovie-ui'), {recursive: true});
await cp(resolve(packageRoot, 'cinemovie-ui'), resolve(vegaRoot, 'assets/cinemovie-ui'), {recursive: true});

const marker = '// CINEMOVIE_VEGA_OVERLAY';
const readme = `\n${marker}\nThis Vega checkout is carrying the Cinemovie UI/resource bundle and the capability-layer source under src/cinemovie-vega/.\n`;
await writeFile(resolve(vegaRoot, 'CINEMOVIE_OVERLAY.md'), readme, 'utf8');

console.log(`Applied overlay to ${vegaRoot}`);
