import {access, stat} from 'node:fs/promises';
import {resolve} from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
for (const p of ['cinemovie-ui/index.html','cinemovie-ui/assets/index-52tEpaFR.css','src/cinemovie-vega/qualitySelection.ts','src/cinemovie-vega/providerRegistry.ts']) {
  const full = resolve(root, p);
  await access(full);
  const s = await stat(full);
  if (s.size === 0) throw new Error(`${p} is empty`);
}
console.log('overlay structure validated');
