import {readFile} from 'node:fs/promises';

// Lightweight static checks so CI can verify the important web-layer rule:
// series episodes support explicit quality/provider choice before playback.
const file = new URL('../src/cinemovie-vega/qualitySelection.ts', import.meta.url);
const text = await readFile(file, 'utf8');
for (const token of ['sortStreams', 'selectStream', 'preferredQuality', 'preferredProviders']) {
  if (!text.includes(token)) throw new Error(`Missing ${token}`);
}
console.log('quality-selection checks passed');
