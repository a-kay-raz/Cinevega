export type MediaType = 'movie' | 'series';

export interface MediaId {
  id: string;
  type: MediaType;
  season?: number;
  episode?: number;
}

export interface ProviderManifest {
  id: string;
  displayName: string;
  version?: string;
  icon?: string;
  enabled?: boolean;
  settings?: Record<string, unknown>;
}

export interface ProviderContext {
  fetch: typeof fetch;
  settings: Record<string, unknown>;
  signal?: AbortSignal;
}

export interface StreamSource {
  id: string;
  providerId: string;
  name: string;
  url?: string;
  externalUrl?: string;
  quality?: string;
  qualityRank?: number;
  language?: string;
  sizeBytes?: number;
  headers?: Record<string, string>;
  subtitles?: SubtitleTrack[];
  audioTracks?: AudioTrack[];
  isHls?: boolean;
  isDash?: boolean;
  title?: string;
  behaviorHints?: Record<string, unknown>;
}

export interface SubtitleTrack {
  id: string;
  label: string;
  language?: string;
  url: string;
  mimeType?: string;
}

export interface AudioTrack {
  id: string;
  label: string;
  language?: string;
}

export interface EpisodeRef {
  season: number;
  episode: number;
  title?: string;
}

export interface ProviderAdapter {
  manifest: ProviderManifest;
  getPosts?: (ctx: ProviderContext, filter: string, page: number) => Promise<unknown[]>;
  getSearchPosts?: (ctx: ProviderContext, query: string, page: number) => Promise<unknown[]>;
  getInfo?: (ctx: ProviderContext, id: string, type: MediaType) => Promise<unknown>;
  getEpisodes?: (ctx: ProviderContext, id: string) => Promise<EpisodeRef[]>;
  getStreams?: (ctx: ProviderContext, media: MediaId) => Promise<StreamSource[]>;
}

export interface QualityPreference {
  autoSelect: boolean;
  preferredQuality: '4K' | '2160p' | '1440p' | '1080p' | '720p' | '480p' | '360p' | 'best';
  preferLanguage?: string;
  preferredProviders?: string[];
}
