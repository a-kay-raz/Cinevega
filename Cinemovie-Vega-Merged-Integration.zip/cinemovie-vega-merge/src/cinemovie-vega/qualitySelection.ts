import type {QualityPreference, StreamSource} from './types.js';

const QUALITY_ORDER: Record<string, number> = {
  '4K': 2160, '2160p': 2160, '1440p': 1440, '1080p': 1080,
  '720p': 720, '576p': 576, '480p': 480, '360p': 360,
};

export function inferQualityRank(stream: StreamSource): number {
  if (stream.qualityRank && stream.qualityRank > 0) return stream.qualityRank;
  const text = `${stream.quality ?? ''} ${stream.name ?? ''} ${stream.title ?? ''}`.toLowerCase();
  for (const [key, value] of Object.entries(QUALITY_ORDER)) {
    if (text.includes(key.toLowerCase())) return value;
  }
  return 0;
}

function preferenceRank(preference: QualityPreference): number {
  if (preference.preferredQuality === 'best') return Number.POSITIVE_INFINITY;
  return QUALITY_ORDER[preference.preferredQuality] ?? Number.POSITIVE_INFINITY;
}

export function sortStreams(streams: StreamSource[], preference: QualityPreference): StreamSource[] {
  const wanted = preferenceRank(preference);
  const providers = new Set(preference.preferredProviders ?? []);
  return [...streams].map(s => ({...s, qualityRank: inferQualityRank(s)})).sort((a, b) => {
    const providerDelta = providers.size ? Number(providers.has(b.providerId)) - Number(providers.has(a.providerId)) : 0;
    if (providerDelta) return providerDelta;
    const aQ = a.qualityRank ?? 0;
    const bQ = b.qualityRank ?? 0;
    if (preference.preferredQuality !== 'best') {
      const aDistance = Math.abs(aQ - wanted);
      const bDistance = Math.abs(bQ - wanted);
      if (aDistance !== bDistance) return aDistance - bDistance;
    }
    if (aQ !== bQ) return bQ - aQ;
    return a.name.localeCompare(b.name);
  });
}

export function selectStream(streams: StreamSource[], preference: QualityPreference): StreamSource | undefined {
  if (!streams.length) return undefined;
  return sortStreams(streams, preference)[0];
}
