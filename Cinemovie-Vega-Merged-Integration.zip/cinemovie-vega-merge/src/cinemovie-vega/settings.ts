import type {QualityPreference} from './types.js';

export interface AppPlaybackSettings extends QualityPreference {
  autoplayMovies: boolean;
  autoplayEpisodes: boolean;
  subtitleFontScale: number;
  preferredSubtitleLanguage?: string;
  preferredAudioLanguage?: string;
  externalPlayerPackage?: string;
}

export const DEFAULT_PLAYBACK_SETTINGS: AppPlaybackSettings = {
  autoSelect: false,
  preferredQuality: '1080p',
  autoplayMovies: true,
  autoplayEpisodes: true,
  subtitleFontScale: 1,
};
