import type {StreamSource, SubtitleTrack, AudioTrack} from './types.js';

export interface PlayerOpenOptions {
  source: StreamSource;
  startPositionMs?: number;
  subtitle?: SubtitleTrack;
  audioTrack?: AudioTrack;
}

export interface PlayerAdapter {
  open(options: PlayerOpenOptions): Promise<void>;
  pause(): Promise<void>;
  resume(): Promise<void>;
  seekTo(positionMs: number): Promise<void>;
  setRate(rate: number): Promise<void>;
  close(): Promise<void>;
}

export class BrowserHlsPlayer implements PlayerAdapter {
  constructor(private readonly video: HTMLVideoElement, private readonly hlsLoader?: (url: string, video: HTMLVideoElement, headers?: Record<string, string>) => Promise<void>) {}

  async open({source, startPositionMs}: PlayerOpenOptions): Promise<void> {
    if (!source.url) throw new Error('Stream has no playable URL');
    if (source.isHls && this.hlsLoader) {
      await this.hlsLoader(source.url, this.video, source.headers);
    } else {
      this.video.src = source.url;
      this.video.load();
    }
    if (typeof startPositionMs === 'number') {
      this.video.currentTime = Math.max(0, startPositionMs / 1000);
    }
    await this.video.play().catch(() => undefined);
  }

  async pause(): Promise<void> { this.video.pause(); }
  async resume(): Promise<void> { await this.video.play(); }
  async seekTo(positionMs: number): Promise<void> { this.video.currentTime = Math.max(0, positionMs / 1000); }
  async setRate(rate: number): Promise<void> { this.video.playbackRate = rate; }
  async close(): Promise<void> { this.video.pause(); this.video.removeAttribute('src'); this.video.load(); }
}
