# CineMovie ↔ Vega capability layer

This folder is a clean integration layer designed to sit between the compiled CineMovie UI extracted from the APK and a Vega-based native runtime.

Included capability contracts:

- provider registry and concurrent stream resolution
- quality-aware stream sorting/selection
- movie/series/season/episode media identity
- subtitles and audio-track models
- player abstraction with HLS-capable browser implementation
- continue-watching persistence
- playback/settings model

The official Vega app remains the native capability provider in the GitHub build: providers, sandboxing, downloads, native player, settings, storage, watchlist, sync, WAF/DNS helpers, etc. are pulled from the official repository at build time. Vega's public README documents streaming/download, multi-audio/external subtitles, WatchList, external player/downloader support, sync and custom sources; v4.0.6 also includes per-provider settings, download queue/pause, subtitle styling, episode selection and intro skipping. [Vega repository](https://github.com/vega-org/vega-app)
