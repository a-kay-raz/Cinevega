import type {MediaId} from './types.js';

export interface WatchState extends MediaId {
  positionMs: number;
  durationMs?: number;
  updatedAt: number;
}

const KEY = 'cinemovie.watchState.v1';

type Store = Record<string, WatchState>;

function read(): Store {
  try { return JSON.parse(localStorage.getItem(KEY) ?? '{}') as Store; }
  catch { return {}; }
}

function key(m: MediaId): string { return [m.type, m.id, m.season ?? '', m.episode ?? ''].join(':'); }

export const watchState = {
  get(media: MediaId): WatchState | undefined { return read()[key(media)]; },
  set(state: WatchState): void {
    const all = read(); all[key(state)] = state; localStorage.setItem(KEY, JSON.stringify(all));
  },
  remove(media: MediaId): void {
    const all = read(); delete all[key(media)]; localStorage.setItem(KEY, JSON.stringify(all));
  },
};
