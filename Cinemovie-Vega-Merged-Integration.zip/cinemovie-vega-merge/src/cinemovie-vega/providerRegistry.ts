import type {ProviderAdapter, ProviderManifest, ProviderContext} from './types.js';

export class ProviderRegistry {
  private readonly providers = new Map<string, ProviderAdapter>();

  register(provider: ProviderAdapter): void {
    if (!provider?.manifest?.id) throw new Error('Provider manifest.id is required');
    this.providers.set(provider.manifest.id, provider);
  }

  unregister(id: string): void {
    this.providers.delete(id);
  }

  list(): ProviderManifest[] {
    return [...this.providers.values()].map(p => p.manifest);
  }

  get(id: string): ProviderAdapter | undefined {
    return this.providers.get(id);
  }

  async resolveStreams(ctx: ProviderContext, media: Parameters<NonNullable<ProviderAdapter['getStreams']>>[0]): Promise<import('./types.js').StreamSource[]> {
    const enabled = [...this.providers.values()].filter(p => p.manifest.enabled !== false && p.getStreams);
    const results = await Promise.allSettled(enabled.map(p => p.getStreams!(ctx, media)));
    const streams: import('./types.js').StreamSource[] = [];
    results.forEach((r, i) => {
      if (r.status === 'fulfilled') streams.push(...r.value);
      else console.warn(`[ProviderRegistry] ${enabled[i].manifest.id}:`, r.reason);
    });
    return streams;
  }
}
